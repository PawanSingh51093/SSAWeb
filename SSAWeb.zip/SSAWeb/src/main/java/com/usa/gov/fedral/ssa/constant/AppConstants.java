package com.usa.gov.fedral.ssa.constant;

public class AppConstants {

	/**
	 * This MESSGE is used to refer message
	 */
	public static final String MESSAGE = "message";

	public static final String SSN_MODEL = "ssnModel";
	public static final String ENROLL_SUCCESS = "enrollSuccess";
	public static final String ENROLL_FAIL = "enrollFail";

	public static final String SUCCESS="success";
	public static final String FAILURE="failure";
	
	
	

}
